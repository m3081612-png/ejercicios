Algoritmo ConteoGlucosa
    Definir n, i, cont_baja, cont_normal, cont_alta Como Entero
    Definir glucosa Como Real
    
    Escribir "Ingrese cantidad de valores a registrar (N):"
    Leer n
    cont_baja <- 0
    cont_normal <- 0
    cont_alta <- 0
    
    Para i <- 1 Hasta n Con Paso 1 Hacer
        Escribir "Ingrese valor de glucosa ", i, ":"
        Leer glucosa
        
        Si glucosa < 70 Entonces
            cont_baja <- cont_baja + 1
        Sino
            Si glucosa <= 140 Entonces
                cont_normal <- cont_normal + 1
            Sino
                cont_alta <- cont_alta + 1
            FinSi
        FinSi
    FinPara
    
    Escribir "Valores < 70: ", cont_baja
    Escribir "Valores entre 70 y 140: ", cont_normal
    Escribir "Valores > 140: ", cont_alta
FinAlgoritmo