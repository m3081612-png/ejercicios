Algoritmo ClasificacionFC
    Definir fc Como Real
    Escribir "Ingrese la frecuencia card�aca:"
    Leer fc
    Si fc < 60 Entonces
        Escribir "Bradicardia"
    Sino
        Si fc <= 100 Entonces
            Escribir "Normal"
        Sino
            Escribir "Taquicardia"
        FinSi
    FinSi
FinAlgoritmo