Algoritmo ValidacionNota
    Definir nota Como Real
    Escribir "Ingrese la nota (0 a 5):"
    Leer nota
    Si nota < 0 O nota > 5 Entonces
        Escribir "Dato inv�lido"
    Sino
        Si nota >= 3 Entonces
            Escribir "Aprueba"
        Sino
            Escribir "Reprueba"
        FinSi
    FinSi
FinAlgoritmo