Algoritmo ConversionTemperatura
		Definir c, f Como Real
		Escribir "Ingrese la temperatura en �C:"
		Leer c
		f <- (c * 9/5) + 32
		Escribir "La temperatura en �F es: ", f
FinAlgoritmo
