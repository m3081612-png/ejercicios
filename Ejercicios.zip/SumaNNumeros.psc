Algoritmo SumaNNumeros
    Definir n, suma, i Como Entero
    Escribir "Ingrese un n�mero N (>0):"
    Leer n
    suma <- 0
    Para i <- 1 Hasta n Con Paso 1 Hacer
        suma <- suma + i
    FinPara
    Escribir "La suma es: ", suma
FinAlgoritmo